*do file for grouping  occ1990 into broader categories; using
*this instead of recode method to keep files clean. Will also test results
*using recode!

*occ1990 recode

gen occ1990_2 = occ1990
cap recode occ1990 (3/37=1) ///
				   (43/200=2) ///
				   (203/235=3) ///
				   (243/283=4) ///
				   (303/389=5) ///
				   (405/469=6) ///
				   (473/498=7) ///
				   (628/699=8) ///
				   (503/549=8) ///
				   (558/599=7) ///
				   (614/617=7) ///
				   (703/799=9) ///
				   (803/889=9) ///
				   (nonmissing=.), ///
				   gen(bocc1990)
				   
*cap rename (occ1990 bocc1990) (occ1990_detail occ1990)
lab define occlabels 1 "Managerial Occupations" ///
					 2 "Professional Specialty Occupations" ///
					 3 "Technicians and Related Support Occupations" ///
					 4 "Sales Occupations" ///
					 5 "Administrative Support Occupations, Including Clerical" ///
					 6 "Service Occupations" ///
					 7 "Farming, Forestry, and Fishing Occupations AND Construction & Extractive Occupations" ///
					 8 "Precision Production Occupations AND Repair" ///
					 9 "Machine Operators, Assemblers, and Inspectors AND Transportation and Material Moving Occupations" ///

cap lab values bocc1990 occlabels
tab bocc1990, miss
drop if bocc1990 > 9


*do file for grouping  occ1990 into broader categories; using
*this instead of recode method to keep files clean. Will also test results
*using recode!

*occ1990_2 recode
cap recode occ1990_2 (3/37=1) ///
				   (43/200=2) ///
				   (203/235=3) ///
				   (243/283=4) ///
				   (303/389=5) ///
				   (405/469=6) ///
				   (473/498=7) ///
				   (628/699=8) ///
				   (503/549=9) ///
				   (558/599=10) ///
				   (614/617=10) ///
				   (703/799=11) ///
				   (803/889=12) ///
				   (nonmissing=.), ///
				   gen(bocc1990_2)
*cap rename (occ1990 bocc1990) (occ1990_detail occ1990)
lab define occlabels_2 1 "Managerial Occupations" ///
					 2 "Professional Specialty Occupations" ///
					 3 "Technicians and Related Support Occupations" ///
					 4 "Sales Occupations" ///
					 5 "Administrative Support Occupations, Including Clerical" ///
					 6 "Service Occupations" ///
					 7 "Farming, Forestry, and Fishing Occupations" ///
					 8 "Precision Production Occupations" ///
					 9 "Repair" ///
					 10 "Construction & Extractive Occupations" ///
					 11 "Machine Operators, Assemblers, and Inspectors" ///
					 12 "Transportation and Material Moving Occupations"
cap lab values bocc1990_2 occlabels_2
tab bocc1990_2, miss
