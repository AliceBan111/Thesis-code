cap log close
clear
#delimit;
set more off;
pause off;
log using onet-construct_2024.txt, text replace;

/* This file utilizes raw ONET Work Activities and Work Context files to construct task categories at the occ1990dd level:

    (1) Insheets raw ONET data for Work Activities, Work Context, Abilities and Skills 
    (2) Standardizes each raw ONET *importance* measure prior to construction of composite measures                            
	(3) Apply 2000 census weights to composite task measures for conversion to occ1990dd occupational categories    

M. Wasserman 2010z
modified by Piotr Zoch 2024
*/

tempfile activities knowledge styles context abilities skills byocc census uncollapsed;

/***************************************************************************************/
/* (1) Insheets raw ONET data for Work Activities, Work Context, Abilities and Skills  */
/***************************************************************************************/

/*******************/
/* Work Activities */
/*******************/

insheet using "Work Activities.txt", tab clear;

keep onetsoccode elementid elementname scaleid datavalue;
/* Convert task measure ID to be compatible with state variable naming conventions */
replace elementid=subinstr(elementid, ".", "", 5); 
preserve;
keep elementid elementname;
save activity_names.dta, replace;
restore;
drop elementname;
/* Reshape so that each observation has Level and Importance measures*/
reshape wide datavalue, i(onetsoccode elementid) j(scaleid) string;



/* drop level */
drop *LV;
rename datavalueIM datavalue;

/* Reshape so each ONET-SOC code has one observation with all work activity task measures */
reshape wide datavalue, i(onetsoccode) j(elementid) string;

renpfix datavalue wa_;



sort onetsoccode;
save `activities';

/***********************/
/* Work Context scores */
/***********************/

insheet using "Work Context.txt", tab clear;
keep if scaleid=="CX";

/* Compute work context task measures = category*data value, where category is on a scale of 1-5 and data value reports the frequency of that category */
destring category, replace;
rename datavalue score;

duplicates drop onetsoccode elementid, force;

keep onetsoccode elementid elementname score;

replace elementid=subinstr(elementid, ".", "", 5); 
preserve;
keep elementid elementname;
save context_names.dta, replace;
restore;
drop elementname;
/* Reshape so ONET-SOC code has one observation with all work context task measures */
reshape wide score, i(onetsoccode) j(elementid) string;

renpfix score wc_;


sort onetsoccode;
save `context';

/*************/
/* Abilities */
/************/

insheet using "Abilities.txt", tab clear;

keep onetsoccode elementid scaleid datavalue;

/* Reshape so that each observation has Level and Importance measures*/
reshape wide datavalue, i(onetsoccode elementid) j(scaleid) string;

/* Convert task measure ID / SOC code to be compatible with stata variable naming conventions */
replace elementid=subinstr(elementid, ".", "", 5); 

/* drop level */
drop *LV;
rename datavalueIM datavalue;

/* Reshape so each ONET-SOC code has one observation with all work activity task measures */
reshape wide datavalue, i(onetsoccode) j(elementid) string;

renpfix datavalue a_;

sort onetsoccode;

save `abilities';

/*****************/
/*** Skills *****/
/****************/

insheet using "Skills.txt", tab clear;

keep onetsoccode elementid scaleid datavalue;

/* Reshape so that each observation has Level and Importance measures*/
reshape wide datavalue, i(onetsoccode elementid) j(scaleid) string;

/* Convert task measure ID / SOC code to be compatible with stata variable naming conventions */
replace elementid=subinstr(elementid, ".", "", 5); 

/* drop level */
drop *LV;
rename datavalueIM datavalue;

/* Reshape so each ONET-SOC code has one observation with all work activity task measures */
reshape wide datavalue, i(onetsoccode) j(elementid) string;

renpfix datavalue s_;

sort onetsoccode;

save `skills';


/*****************/
/*** Knowledge *****/
/****************/

insheet using "Knowledge.txt", tab clear;

keep onetsoccode elementid scaleid datavalue;

/* Reshape so that each observation has Level and Importance measures*/
reshape wide datavalue, i(onetsoccode elementid) j(scaleid) string;

/* Convert task measure ID / SOC code to be compatible with stata variable naming conventions */
replace elementid=subinstr(elementid, ".", "", 5); 

/* drop level */
drop *LV;
rename datavalueIM datavalue;

/* Reshape so each ONET-SOC code has one observation with all work activity task measures */
reshape wide datavalue, i(onetsoccode) j(elementid) string;

renpfix datavalue k_;

sort onetsoccode;

save `knowledge';


/*****************/
/*** Styles *****/
/****************/

insheet using "Work Styles.txt", tab clear;

keep onetsoccode elementid scaleid datavalue;

/* Reshape so that each observation has Level and Importance measures*/
reshape wide datavalue, i(onetsoccode elementid) j(scaleid) string;

/* Convert task measure ID / SOC code to be compatible with stata variable naming conventions */
replace elementid=subinstr(elementid, ".", "", 5); 

rename datavalueIM datavalue;

/* Reshape so each ONET-SOC code has one observation with all work activity task measures */
reshape wide datavalue, i(onetsoccode) j(elementid) string;

renpfix datavalue ws_;

sort onetsoccode;

save `styles';

/**********************/
/* Merge all together */
/**********************/

use `activities', clear;
merge onetsoccode using `context';
assert _merge==3;
drop _merge;
sort onetsoccode;
merge onetsoccode using `abilities';
assert _merge==3;
drop _merge;

sort onetsoccode;
merge onetsoccode using `skills';
tab _merge;

/* Some occupations do not have skill ratings - impute those that are not ONET two decimal extensions of SOC codes*/
list onet if _merge==1;
drop _merge;
sort onetsoccode;


merge onetsoccode using `knowledge';
assert _merge==3;
drop _merge;

sort onetsoccode;
merge onetsoccode using `styles';
tab _merge;

/* Some occupations do not have styles ratings - impute those that are not ONET two decimal extensions of SOC codes*/
list onet if _merge==1;
drop _merge;
sort onetsoccode;



/* Aggregate to the SOC code level */
replace onetsoccode = subinstr(onetsoccode, "-", "", 1);
destring onetsoccode, replace;
gen soc=int(onetsoccode);
list soc onetsoccode if soc!=onetsoccode;

collapse (mean) wa_* wc_* s_* a_* k_* ws_* , by(soc);

list soc if s_2B1a ==.;
pause;

/************************************************************************************/
/* (2) Apply SOC weights to composite task measures for conversion to 2000 Census   */
/************************************************************************************/

/* Merge with SOC weights for standardization/collapse */
rename soc soc2000;
sort soc2000;
* merge soc2000 using ../../crosswalk/dta/soc-census-weights;
merge soc2000 using soc-census-weights;
tab _merge;
pause;
drop if _merge==1;
drop _merge;

rename soc2000 onetsoccode;

/***************************************************************************************************/
/* (3) Standardizes each raw ONET *importance* measure prior to construction of composite measures */
/***************************************************************************************************/

foreach var of varlist wc_* wa_* s_* a_* k_* ws_*
{;
	summ `var' [aw=socwt];
	replace `var'= (`var'- r(mean) ) / r(sd);
};

/*
/***************************************/
/* (4) Creates composite task measures */
/***************************************/

/* Non-routine cognitive: Analytical */
/* 4.A.2.a.4 Analyzing data/information
   4.A.2.b.2 Thinking creatively
   4.A.4.a.1 Interpreting information for others */

egen nr_cog_anal=rowtotal(t_4A2a4 t_4A2b2 t_4A4a1); 

/* Non-routine cognitive: Interpersonal */
/* 4.A.4.a.4 Establishing and maintaining personal relationships
   4.A.4.b.4 Guiding, directing and motivating subordinates 
   4.A.4.b.5 Coaching/developing others
*/

egen nr_cog_pers=rowtotal(t_4A4a4 t_4A4b4 t_4A4b5);

/* Routine cognitive */
/* 4.C.3.b.7 Importance of repeating the same tasks
   4.C.3.b.4 Importance of being exact or accurate
   4.C.3.b.8 Structured v. Unstructured work (reverse)
*/

 egen r_cog=rowtotal(t_4C3b7 t_4C3b4 t_4C3b8_rev);

/* Routine manual */
/* 4.C.3.d.3 Pace determined by speed of equipment
   4.A.3.a.3 Controlling machines and processes 
   4.C.2.d.1.i Spend time making repetitive motions 
*/

egen r_man=rowtotal(t_4C3d3 t_4A3a3 t_4C2d1i);

/* Non-routine manual: phys. adaptability */
/* 4.A.3.a.4 Operating vehicles, mechanized devices, or equipment
   4.C.2.d.1.g Spend time using hands to handle, control or feel objects, tools or controls
   1.A.2.a.2 Manual dexterity
   1.A.1.f.1 Spatial orientation
*/

egen nr_man_phys=rowtotal(t_4A3a4 t_4C2d1g t_1A2a2 t_1A1f1);

/* Non-routine manual: interpersonal adaptability */
/* 2.B.1.a Social Perceptiveness*/

egen nr_man_pers=rowtotal(t_2B1a); 
replace nr_man_pers=. if t_2B1a==.;

/* Offshorability measure: average of FFL Onsite and Face to face without overlapping measures */

/* multiply equipment repair categories by 0.5*/
replace t_4A3b4_rev=t_4A3b4_rev*0.5;
replace t_4A3b4_rev=t_4A3b5_rev*0.5;

egen offshor=rowtotal(t_4C1a2l_rev t_4A4a5_rev t_4A4a8_rev t_4A1b2_rev t_4A3a2_rev t_4A3b4_rev t_4A3b5_rev);
  
drop t_*;
   
foreach var of varlist nr_cog_anal-offshor
{;
	summ `var' [aw=socwt];
	replace `var'= (`var'-r(mean))/r(sd);
};

save `uncollapsed', replace;
*/
save onet-soc_detailed.dta, replace;

/*  COMMENTED OUT, NOT USED

/* Collapse into major SOC categories */
replace onetsoccode=int(onetsoccode/10000);
collapse (mean) nr_* r_* offshor* (rawsum) socwt [aw=socwt], by(onetsoccode);

/* Label SOC Major categories */
label define occ 11 "Management" 13 "Business/Financial" 15 "Computer/Mathematical" 17 "Architecture/Engineering" 19 "Life, Physical, Social Science" 21 "Community/Social Services" 23 "Legal" 25 "Education, Training Library" 
	27 "Art, Design, Entertainment, Sports, Media"  29 "Healthcare Practitioners and technical" 31 "Healthcare Support" 33 "Protective Services" 35 "Food Prep and Service-related" 37 "Building/grounds cleaning and maintenance"
	39 "Personal care and service" 41 "Sales" 43 "Office/Admin support" 45 "Farming, fishing, forestry" 47 "Construction and extraction" 49 "Installation, maintenance, repair" 51 "Production" 
	53 "Transportation and material moving";
label val onetsoccode occ;

outsheet using ../out/onet-task-measure-bySOC.csv, comma replace;
save ../dta/onet-task-measure-bySOC.dta, replace;

use `uncollapsed', clear;

/* Tabulate task measures by education/gender using Census 2000 data */

/* First collapse to Census occupation codes for merge with Census 2000 data */
collapse (mean) nr_* r_* offshor* (rawsum) socwt [aweight=socwt], by(occ2000);
rename occ2000 occ;
sort occ ;

save `byocc', replace;

/* Census 2000 Data */
use ../../census-acs/dta/microwage2000_ext, clear;
sort occ;

merge occ using `byocc';
tab _merge;
tab occ if _merge!=3;
drop if _merge!=3;

save `census', replace;

/*Collapse to educational categories */
gen edcat5=1 if ed_0 | ed_1_4 | ed_5_8 | ed_9 | ed_10 | ed_11;
replace edcat5=2 if ed_12;
replace edcat5=3 if ed_13_15;
replace edcat5=4 if ed_16;
replace edcat5=5 if ed_17up;
assert edcat5!=.;

collapse (mean) nr_* r_* offshor* (rawsum) perwt [aweight=perwt], by(edcat5);

save ../dta/onet-task-development-education.dta, replace;
outsheet using ../out/onet-task-measure-byED.csv, comma replace;

/* Collapse to gender categories */
use `census', clear;

collapse (mean) nr_* r_* offshor* (rawsum)  perwt [aweight=perwt], by(female);

save ../dta/onet-task-development-gender.dta, replace;
outsheet using ../out/onet-task-measure-byGEN.csv, comma replace;
*/    

/****************************************************************************************/
/* (5) Convert to 2000 Census occupation categories                                     */
/****************************************************************************************/

rename onetsoc soc2000;
sort soc2000;

/* Two SOC codes not found in crosswalk, 65 SOC codes not found in ONET*/

/* These two unmatched ONET-SOC codes are classified 'at an exceptional level' by ONET and do not correspond to a utilized SOC code (only SOC header codes); We will drop these from our ONET task measure sample */

collapse (mean)  s_* wa_* wc_* a_* k_* ws_* (rawsum) socwt [aweight=socwt], by(occ2000);


save onet-soc-census-2000_detailed.dta, replace;

sort occ2000;

/****************************************************************************************/
/* (6) Apply 2000 census weights to composite task measures for conversion to occ1990dd */
/****************************************************************************************/

merge occ2000 using census-2000-1990dd-weights.dta;
tab _merge;
list occ2000 occ1990dd if _merge!=3;
drop _merge tag*;

/* Impute occ2000 task measures for Census 2000 code 373  using 370, 371, 372 (supervisors of protective services) */
/*
pause;
foreach t in  s_*
{;
    qui summ `t' if occ2000==373;
    qui summ `t' if occ2000==370 | occ2000==371 | occ2000==372 [aw=lswt];
    replace `t'=r(mean) if occ2000==373;
}; 

/* Certain 2000 Census occs without nr_man_pers and prox task measures: Impute where possible */

list occ2000 if nr_man_pers==.;

/* Cannot impute (3) Legislators */

/* NR_MAN_PERS */

summ nr_man_pers if occ2000>=1 & occ2000<=42 [aw=lswt];
replace nr_man_pers=r(mean) if occ2000==43;

summ nr_man_pers if occ2000>=80 & occ2000<=94 [aw=lswt];
replace nr_man_pers=r(mean) if occ2000==95;

summ nr_man_pers if occ2000>=160 & occ2000<=174 [aw=lswt];
replace nr_man_pers=r(mean) if occ2000==176;

summ nr_man_pers if occ2000>=200 & occ2000<=205 [aw=lswt];
replace nr_man_pers=r(mean) if occ2000==206;

summ nr_man_pers if occ2000>=260 & occ2000<=275 [aw=lswt];
replace nr_man_pers=r(mean) if occ2000==276;

summ nr_man_pers if occ2000>=315 & occ2000<=323 [aw=lswt];
replace nr_man_pers=r(mean) if occ2000==324;

summ nr_man_pers if occ2000>=300 & occ2000<=314 [aw=lswt];
replace nr_man_pers=r(mean) if occ2000==326;

summ nr_man_pers if occ2000>=430 & occ2000<=464 [aw=lswt];
replace nr_man_pers=r(mean) if occ2000==465;

summ nr_man_pers if occ2000>=475 & occ2000<=483 [aw=lswt];
replace nr_man_pers=r(mean) if occ2000==484;

summ nr_man_pers if occ2000>=485 & occ2000<=495 [aw=lswt];
replace nr_man_pers=r(mean) if occ2000==496;

summ nr_man_pers if occ2000>=501 & occ2000<=502 [aw=lswt];
replace nr_man_pers=r(mean) if occ2000==503;

summ nr_man_pers if occ2000>=510 & occ2000<=541 [aw=lswt];
replace nr_man_pers=r(mean) if occ2000==542;

summ nr_man_pers if occ2000>=550 & occ2000<=592 [aw=lswt];
replace nr_man_pers=r(mean) if occ2000==593;

foreach task in wa_* wc_* s_* a_*
{;
    assert `task'!=. if occ2000!=3;
};
*/
save onet-task-occ2000_detailed.dta, replace;

collapse (mean)  wa_* wc_* s_* a_* k_* ws_*  (rawsum) lswt [aweight=lswt], by(occ1990dd);

save onet-task-1990dd_detailed.dta, replace;

* only activities;
keep wa_* occ1990dd lswt;

reshape long wa_, i(occ1990dd) j(elementid) string;
merge m:m elementid  using activity_names.dta;
log close;
