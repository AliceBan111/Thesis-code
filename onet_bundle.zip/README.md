# O*NET Task Construction Bundle

This bundle builds O*NET task measures at the `occ1990dd` occupation level, which can then be merged into occupation-level datasets.

## Contents

```
tasks/
  onet-construct_2024.do          # the script to run
  Work Activities.txt             # raw O*NET inputs (tab-delimited)
  Work Context.txt
  Abilities.txt
  Skills.txt
  Knowledge.txt
  Work Styles.txt
  soc-census-weights.dta          # SOC -> occ2000 weights
  census-2000-1990dd-weights.dta  # occ2000 -> occ1990dd weights
  activity_names.dta              # element name lookup (diagnostic only)
crosswalks/
  xwalk_occ.do                    # occ1990 -> 9-group (id_occ_9) recode
```

## How to run

1. `cd` into `tasks/` in Stata (the script uses relative paths).
2. `do onet-construct_2024.do`

## Outputs (written into `tasks/`)

- **`onet-task-1990dd.dta`** — one row per `occ1990dd`, columns `wa_*`, `wc_*`, `s_*`, `a_*`, `k_*`, `ws_*` (standardized element scores for Work Activities, Work Context, Skills, Abilities, Knowledge, Work Styles).
- **`onet-task-1990dd_detailed.dta`** — same structure, unfiltered variant.

This is the file to merge onto occupation-level data on key `occ1990dd`.

## O*NET version

The raw `.txt` files in this bundle are one specific O*NET release. Note the release date if you replace them — element IDs and scale IDs drift across versions and will break variable names.

## From `occ1990dd` to a 9-group aggregation (`id_occ_9`)

The script output is keyed on `occ1990dd` (detailed "Dorn" 1990 Census codes). The downstream analysis uses a 9-group aggregation called `id_occ_9`, defined by `crosswalks/xwalk_occ.do` as a recode of `occ1990` (3-digit 1990 Census).

`xwalk_occ.do` does **not** map `occ1990dd` directly. Two options:

1. Apply the recode after collapsing to `occ1990` (aggregate the `dd` codes to their 3-digit parents first, then apply `xwalk_occ.do`).
2. Ask Piotr for a pre-built `occ1990dd -> id_occ_9` lookup extracted from the ACS-based `acs_summary_occ1990dd.dta`.

Option 2 is cleaner if all you need is a task file keyed to `id_occ_9`.

## Notes / caveats

- The script contains commented-out composite-task construction (nr_cog_anal, r_cog, r_man, nr_man_phys, etc.) — output is the raw standardized element scores, not the Autor-style composites. This is intentional.
- There is one cosmetic `merge m:m elementid using activity_names.dta` at the very end of the script (diagnostic block, runs after the main outputs are saved). It does not affect `onet-task-1990dd.dta`. Safe to leave alone, or change to `merge m:1` for hygiene.
- The script uses `#delimit ;` — every statement ends in `;`.
